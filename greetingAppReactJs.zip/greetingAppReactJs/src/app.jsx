
import React from 'react';


let app = () => {
        const name = 'Mritunjay'
        let currDate = new Date();
        let timeTosleep = ''
        currDate = currDate.getHours();
        let greeting = ''
        let csstyle = {};


        if (currDate >= 1 && currDate < 12) {
                greeting = 'Good Morning 🌄';
                csstyle.color = 'green'

        } else if (currDate >= 12 && currDate < 20) {
                greeting = 'Good afternoon 🌞';
                csstyle.color = 'orange'

        } else {

                greeting = `It's  ${timeTosleep = new Date().toLocaleTimeString()} please sleep.
                 Good Night 😴` ;
                csstyle.color = 'Black'
        }
        return (
                <>
                        <div className="greeting_holder">
                                <h3>Hello {name}, <span style={csstyle}>{greeting}</span></h3>
                        </div>
                </>
        );
}



export default app;